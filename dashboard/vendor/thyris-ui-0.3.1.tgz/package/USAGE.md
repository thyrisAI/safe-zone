# `@thyris/ui` Usage Guide

This guide explains how to install, configure, and use the private
`@thyris/ui` package in a React application. For the complete component API
and accessibility notes, see [`README.md`](./README.md).

## Requirements

- Node.js 20.9 or newer
- React and React DOM 19.2.x
- TypeScript 5.5 or newer
- Tailwind CSS 3.4.x

The package owns its Radix UI, Lucide, React Hook Form, Recharts, CVA, clsx,
and Tailwind Merge dependencies. The consuming application owns React,
React DOM, Tailwind CSS, and its build configuration.

## Installation

### In this workspace

Add the workspace package to the consuming application's `package.json`:

```json
{
  "dependencies": {
    "@thyris/ui": "workspace:*"
  }
}
```

Then install dependencies from the repository root:

```bash
pnpm install
```

### In another private repository

Copy the required versioned archives from `releases/<version>/` into
the consumer repository, then install it:

```bash
pnpm add ./vendor/thyris-ui-0.1.0.tgz
```

Keep the archive in the consumer repository when that repository must install
without access to this workspace. Do not copy individual component source
files. See [`../../RELEASE.md`](../../RELEASE.md) for versioning, checksums,
and the complete release procedure.

## Tailwind setup

Install the Tailwind animation plugin if the consumer does not already use it:

```bash
pnpm add -D tailwindcss@^3.4 tailwindcss-animate@^1
```

Add the package files to `content`, enable class-based dark mode, register the
animation plugin, and map the semantic tokens in `tailwind.config.ts`:

```ts
import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: "class",
  content: [
    "./src/**/*.{ts,tsx}",
    "./node_modules/@thyris/ui/dist/**/*.{js,mjs}",
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

export default config
```

When developing inside the central UI workspace, the Design Library scans the
source paths directly:

```ts
content: [
  "./src/**/*.{ts,tsx}",
  "../packages/ui/src/**/*.{ts,tsx}",
]
```

Adjust the relative path for the consumer's location.

## Global styles and themes

Import the canonical tokens once, before the Tailwind layers, in the
application's global stylesheet:

```css
@import "@thyris/ui/tokens.css";

@tailwind base;
@tailwind components;
@tailwind utilities;
```

Apply the semantic page colors at the application shell:

```tsx
export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {children}
    </div>
  )
}
```

Add `dark` to the document root to activate the dark token set:

```ts
document.documentElement.classList.toggle("dark", isDark)
```

Use `force-light` on a subtree that must always use the light token values.
Consumer-specific brand and status colors should remain in the consumer;
shared components should continue to use semantic names such as `primary`,
`muted`, and `destructive`.

## Importing components

Prefer the public root export:

```tsx
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@thyris/ui"

export function AccountCard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Account</CardTitle>
        <CardDescription>Manage the current account.</CardDescription>
      </CardHeader>
      <CardContent>
        <Button type="button">Save changes</Button>
      </CardContent>
    </Card>
  )
}
```

Never import from `@thyris/ui/src/*`. Supported subpath imports, such as
`@thyris/ui/button`, are available when a narrow import is necessary.

## Links styled as buttons

Use `asChild` to preserve link semantics:

```tsx
import Link from "next/link"
import { Button } from "@thyris/ui"

export function SettingsLink() {
  return (
    <Button asChild variant="outline">
      <Link href="/settings">Open settings</Link>
    </Button>
  )
}
```

Do not use a click handler to imitate navigation.

## Dialogs

Compose dialog parts and always provide a title:

```tsx
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@thyris/ui"

export function DeleteDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="destructive">Delete account</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete account?</DialogTitle>
          <DialogDescription>
            This action cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="button" variant="destructive">
            Confirm deletion
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
```

Use `ResponsiveDialogContent`, `ResponsiveDialogHeader`,
`ResponsiveDialogBody`, and `ResponsiveDialogFooter` for long or
viewport-sensitive tasks.

## Forms

The form helpers integrate with React Hook Form:

```tsx
"use client"

import { useForm } from "react-hook-form"
import {
  Button,
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  Input,
} from "@thyris/ui"

type ProfileValues = {
  displayName: string
}

export function ProfileForm() {
  const form = useForm<ProfileValues>({
    defaultValues: { displayName: "" },
  })

  return (
    <Form {...form}>
      <form
        className="space-y-4"
        onSubmit={form.handleSubmit((values) => console.log(values))}
      >
        <FormField
          control={form.control}
          name="displayName"
          rules={{ required: "Display name is required." }}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Display name</FormLabel>
              <FormControl>
                <Input autoComplete="name" {...field} />
              </FormControl>
              <FormDescription>Shown to other team members.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit">Save profile</Button>
      </form>
    </Form>
  )
}
```

Install `react-hook-form` directly in the consumer when application code
imports `useForm` or its public types.

## Client components

Interactive primitives already declare their client boundary. Add
`"use client"` to a consuming Next.js component when it owns state, event
handlers, browser APIs, or hooks. Static composition can remain in a Server
Component when no client-only props cross the boundary.

## Utilities

Use `cn` to merge conditional classes safely:

```tsx
import { cn } from "@thyris/ui"

export function Panel({
  active,
  className,
}: {
  active: boolean
  className?: string
}) {
  return (
    <section
      className={cn(
        "rounded-lg border bg-card p-4 text-card-foreground",
        active && "ring-2 ring-ring",
        className,
      )}
    />
  )
}
```

Use `useMediaQuery` only for client-side behavior. Critical content and layout
must remain usable before hydration.

## Accessibility checklist

- Give icon-only controls an accessible name.
- Associate every form control with a visible label.
- Include `DialogTitle` in every dialog.
- Preserve keyboard focus styles and Radix keyboard behavior.
- Do not communicate status through color alone.
- Provide a textual summary or table for essential chart data.

## Troubleshooting

### Components render without styling

Confirm that `tokens.css` is imported, Tailwind scans the installed package,
and `tailwindcss-animate` is enabled. Restart the development server after
changing Tailwind content paths.

### Semantic colors are missing

Copy the semantic color and radius mappings into the consumer's Tailwind
configuration. Importing the token CSS alone defines variables but does not
create Tailwind utilities such as `bg-background`.

### React hook or context errors

Ensure the consumer resolves a single React and React DOM installation that
satisfies the package peer ranges. Do not bundle a second React runtime into a
local package copy.

### An import works in the workspace but fails from a release archive

Use only exports documented in [`README.md`](./README.md) and avoid `src`
paths. Rebuild the release after adding a new public export.

## Updating the package

Install both UI packages at the same version when the consumer also uses
`@thyris/ui-patterns`. Review both changelogs, replace the archived tarballs,
reinstall dependencies, and run the consumer's type check before merging.

# `@thyris/ui`

Private, application-agnostic React primitives for the Thyris workspace. This
package owns reusable controls, structure, interaction behavior, design tokens,
`cn`, and `useMediaQuery`. It must not import application routes, API clients,
authentication, database code, or domain services.

Consume public exports from `@thyris/ui`; do not deep-import `src` files. Load
`@thyris/ui/tokens.css` once before the consuming application's Tailwind layer.
Compose business workflows in the application or `@thyris/ui-patterns`.
For use outside this workspace, create and transfer the private local release
archives described in [`RELEASE.md`](../../RELEASE.md); do not copy
individual source files into a consumer.

Start with the [`usage guide`](./USAGE.md) for installation, Tailwind setup,
theming, component recipes, and troubleshooting.

The supported React, TypeScript, Tailwind, browser, Radix, Lucide, React Hook
Form, Recharts, and Tailwind Merge versions are defined in
`design-library/PORTABILITY.md`. Shared primitives use semantic tokens only;
consumer-specific brand and status colors belong to the consuming application.
Lucide is the only generic icon library allowed in this package.

Every component entry below is part of the documentation contract checked by
`pnpm --filter @thyris/design-library check:docs`. Story names use the Storybook sidebar path.

## Components

<!-- component: alert -->
### Alert

- **Purpose:** Presents a prominent informational or destructive message.
- **Usage:** Use `Alert`, `AlertTitle`, and `AlertDescription` for contextual page or form feedback.
- **API:** Supports native `div` props and `variant="default" | "destructive"`.
- **Accessibility:** Keep the title and description meaningful; add a live-region role only when a new message must be announced.
- **Responsive:** It is fluid by default; allow long text and actions to wrap.
- **Do:** Use destructive styling for an actionable error with recovery guidance.
- **Don't:** Use an alert as a substitute for ordinary body copy or a confirmation dialog.
- **Related:** Dialog, Card, EmptyState.
- **Storybook:** `Primitives/Feedback` → Alert.

<!-- component: avatar -->
### Avatar

- **Purpose:** Displays a person or entity image with a resilient fallback.
- **Usage:** Compose `Avatar`, `AvatarImage`, and `AvatarFallback`.
- **API:** Each part accepts the corresponding Radix Avatar props and `className`.
- **Accessibility:** Give meaningful images useful `alt` text; use an empty `alt` when adjacent text already identifies the entity.
- **Responsive:** Choose an explicit size for the surrounding context and keep the avatar from shrinking unexpectedly.
- **Do:** Provide initials or a short recognizable fallback.
- **Don't:** Rely on the image alone to communicate identity in critical actions.
- **Related:** Badge, DropdownMenu, Sidebar.
- **Storybook:** `Primitives/Feedback` → Avatar.

<!-- component: badge -->
### Badge

- **Purpose:** Labels compact status, category, or metadata.
- **Usage:** Place beside a title or table value when a short visual label improves scanning.
- **API:** Supports native `div` props and `variant="default" | "secondary" | "destructive" | "outline"`.
- **Accessibility:** Include status text; color must not be the only differentiator.
- **Responsive:** Keep labels brief and permit wrapping where narrow containers cannot fit them.
- **Do:** Use stable wording such as “Active” or “Draft”.
- **Don't:** Put primary actions or long sentences inside a badge.
- **Related:** Alert, MetricCard, Table.
- **Storybook:** `Primitives/Feedback` → Badge.

<!-- component: breadcrumb -->
### Breadcrumb

- **Purpose:** Communicates the current page's position in a hierarchy.
- **Usage:** Compose `BreadcrumbList`, `BreadcrumbItem`, links, separators, and one `BreadcrumbPage`.
- **API:** Exposes semantic breadcrumb parts, `asChild` links, and `BreadcrumbEllipsis`.
- **Accessibility:** Preserve the `nav`/ordered-list structure and mark only the current page with `aria-current="page"`.
- **Responsive:** Collapse middle segments with the ellipsis or hide low-value ancestors on small screens.
- **Do:** Keep labels aligned with real navigation destinations.
- **Don't:** Render arbitrary `div` children directly inside the ordered list.
- **Related:** PageHeader, Sidebar, Tabs.
- **Storybook:** `Primitives/Navigation` → Breadcrumb.

<!-- component: button -->
### Button

- **Purpose:** Triggers an action or adopts link semantics through a slotted child.
- **Usage:** Use the visual hierarchy that matches the action's importance.
- **API:** Native button props, `asChild`, `variant="default" | "destructive" | "outline" | "secondary" | "ghost" | "link"`, and `size="default" | "sm" | "lg" | "icon"`.
- **Accessibility:** Icon-only buttons require an accessible name; keep disabled state and keyboard focus visible.
- **Responsive:** Let text buttons wrap only intentionally; use compact or icon sizing where space is constrained.
- **Do:** Set `type="button"` for non-submit controls inside forms.
- **Don't:** Use a button for navigation unless `asChild` wraps a semantic link.
- **Related:** Toggle, Dialog, BulkActionToolbar.
- **Storybook:** `Primitives/Actions` → Button.

<!-- component: card -->
### Card

- **Purpose:** Groups related content and actions within a bounded surface.
- **Usage:** Compose `CardHeader`, `CardTitle`, `CardDescription`, `CardContent`, and `CardFooter` as needed.
- **API:** All parts accept native `div` props and `className`.
- **Accessibility:** Maintain a logical heading order; the caller is responsible for choosing semantic headings.
- **Responsive:** Reduce optional density and allow header actions to stack in narrow cards.
- **Do:** Keep one clear subject per card.
- **Don't:** Nest multiple card borders solely to create spacing.
- **Related:** MetricCard, Alert, Chart.
- **Storybook:** `Primitives/Data Display` → Card.

<!-- component: chart -->
### Chart

- **Purpose:** Provides themed Recharts containers, legends, and tooltips.
- **Usage:** Wrap a Recharts visualization in `ChartContainer` with a stable `ChartConfig`.
- **API:** Exposes `ChartContainer`, `ChartTooltip`, `ChartTooltipContent`, `ChartLegend`, `ChartLegendContent`, and `ChartStyle`.
- **Accessibility:** Supply an accessible chart label and an equivalent textual summary or table for essential values.
- **Responsive:** Give the container a deliberate height and verify labels at phone, tablet, and desktop widths.
- **Do:** Use token-backed series colors and concise tooltip labels.
- **Don't:** Encode meaning only through color or hide required data exclusively in hover content.
- **Related:** Card, EnrichmentUsageChartPresentation, MetricCard.
- **Storybook:** `Primitives/Data Display` → Chart.

<!-- component: checkbox -->
### Checkbox

- **Purpose:** Selects an independent boolean or a set of rows/items.
- **Usage:** Pair the control with a visible `Label` and controlled or uncontrolled checked state.
- **API:** Supports native-style checkbox props including `checked`, `defaultChecked`, `onCheckedChange`, `disabled`, `name`, and `value`.
- **Accessibility:** Associate a label, preserve focus indication, and communicate mixed state when selection is indeterminate.
- **Responsive:** Keep the target and label together; let long label text wrap.
- **Do:** Use for zero-or-more selections.
- **Don't:** Use checkboxes where exactly one option must be selected.
- **Related:** RadioGroup, Switch, BulkActionToolbar.
- **Storybook:** `Primitives/Inputs` → Checkbox.

<!-- component: collapsible -->
### Collapsible

- **Purpose:** Reveals and hides secondary content inline.
- **Usage:** Compose `Collapsible`, `CollapsibleTrigger`, and `CollapsibleContent`.
- **API:** Each part forwards the corresponding Radix Collapsible props and state.
- **Accessibility:** Use a semantic trigger with a clear name; Radix manages expanded state and keyboard activation.
- **Responsive:** Ensure revealed content fits or scrolls within the available viewport.
- **Do:** Use for optional detail that does not require modal focus.
- **Don't:** Hide essential form errors or primary actions by default.
- **Related:** Sidebar, Dialog, Popover.
- **Storybook:** `Primitives/Overlays` → Collapsible.

<!-- component: dialog -->
### Dialog

- **Purpose:** Holds a focused modal task, decision, or explanation.
- **Usage:** Compose root, trigger, content, header, title, description, footer, and close; use responsive dialog parts when the presentation changes by viewport.
- **API:** Exposes Radix dialog parts plus `ResponsiveDialog*` helpers and native presentation props.
- **Accessibility:** Always provide a title, add a description when useful, preserve focus trapping/restoration, and label icon-only close controls.
- **Responsive:** Content is viewport-bounded; stack dense footer actions and test the responsive sheet/dialog transition.
- **Do:** Keep the task focused and make cancel/close behavior predictable.
- **Don't:** Nest dialogs or use a modal for passive information that belongs inline.
- **Related:** WizardDialogShell, Popover, Alert.
- **Storybook:** `Primitives/Overlays` → Dialog and Responsive Dialog.

<!-- component: dropdown-menu -->
### Dropdown Menu

- **Purpose:** Presents a compact list of contextual commands or choices.
- **Usage:** Compose `DropdownMenu`, trigger, content, items, groups, labels, separators, checkbox/radio items, and submenus.
- **API:** Forwards Radix Dropdown Menu props and supports `inset` presentation on applicable parts.
- **Accessibility:** Give the trigger an accessible name, keep items action-oriented, and preserve built-in arrow-key/typeahead behavior.
- **Responsive:** Use collision-aware alignment and keep content inside the viewport.
- **Do:** Use for secondary commands attached to a clear trigger.
- **Don't:** Place complex forms or primary page navigation in a dropdown menu.
- **Related:** Button, Popover, Sidebar.
- **Storybook:** `Primitives/Overlays` → Dropdown Menu.

<!-- component: field -->
### Field

- **Purpose:** Standardizes label, control, description, and error layout.
- **Usage:** Use `Field`, `FieldLabel`, `FieldDescription`, `FieldError`, `FieldGroup`, `FieldSet`, and `FieldLegend` around form controls.
- **API:** Parts accept native element props; `FieldError` accepts validation error objects or children.
- **Accessibility:** Connect labels, descriptions, and errors to the control with stable IDs and `aria-describedby`.
- **Responsive:** Use vertical layout by default and allow grouped controls to stack on narrow screens.
- **Do:** Keep help text and validation next to the affected control.
- **Don't:** Communicate an error using color alone.
- **Related:** Form, Label, Input.
- **Storybook:** `Primitives/Inputs` → Field.

<!-- component: form -->
### Form

- **Purpose:** Bridges React Hook Form state with accessible field composition.
- **Usage:** Use `Form`, `FormField`, `FormItem`, `FormLabel`, `FormControl`, `FormDescription`, and `FormMessage`.
- **API:** Wraps React Hook Form provider/controller APIs and exposes `useFormField`.
- **Accessibility:** Generated IDs associate controls, descriptions, and errors; retain `aria-invalid` and error messaging.
- **Responsive:** Layout belongs to the caller; stack fields before labels or errors become cramped.
- **Do:** Render validation messages through `FormMessage`.
- **Don't:** Use these helpers outside a matching React Hook Form provider.
- **Related:** Field, Input, WizardDialogShell.
- **Storybook:** `Primitives/Inputs` → Form / Validation.

<!-- component: input -->
### Input

- **Purpose:** Captures a single line of text, numbers, dates, or other native input values.
- **Usage:** Pair with `Label` or form helpers and choose the correct native `type` and autocomplete metadata.
- **API:** Forwards native `input` props and `ref`.
- **Accessibility:** Provide an associated name, preserve visible focus, and connect help/error text.
- **Responsive:** Defaults to full width; prevent browser zoom issues by retaining readable mobile text size.
- **Do:** Use native input types and autocomplete values where available.
- **Don't:** Put placeholder text in place of a persistent label.
- **Related:** Label, Field, Textarea.
- **Storybook:** `Primitives/Inputs` → Input.

<!-- component: label -->
### Label

- **Purpose:** Gives a form control a visible, clickable name.
- **Usage:** Set `htmlFor` to the target control ID or use it within an accessible form composition.
- **API:** Forwards Radix Label root props and `ref`.
- **Accessibility:** Keep the wording concise and ensure the association resolves to exactly one intended control.
- **Responsive:** Allow labels to wrap without covering their controls.
- **Do:** Indicate optional/required state in text when users need it.
- **Don't:** Use a styled label as a generic heading.
- **Related:** Input, Field, Checkbox.
- **Storybook:** `Primitives/Inputs` → Label.

<!-- component: popover -->
### Popover

- **Purpose:** Displays non-modal contextual content anchored to a trigger.
- **Usage:** Compose `Popover`, `PopoverTrigger`, and `PopoverContent`.
- **API:** Forwards Radix Popover props; content supports alignment, side offset, and collision behavior.
- **Accessibility:** Use a named keyboard-operable trigger and keep focus behavior appropriate for interactive content.
- **Responsive:** Choose alignment deliberately and ensure the content width never exceeds the viewport.
- **Do:** Use for lightweight contextual controls or explanations.
- **Don't:** Use for destructive confirmation or a long multi-step workflow.
- **Related:** Tooltip, DropdownMenu, Dialog.
- **Storybook:** `Primitives/Overlays` → Popover.

<!-- component: progress -->
### Progress

- **Purpose:** Shows determinate task or quota completion.
- **Usage:** Pass a numeric value and an accessible label in the surrounding context.
- **API:** Forwards native `div` props and accepts `value`; the indicator transform reflects the percentage.
- **Accessibility:** Supply a name and meaningful `aria-valuemin`, `aria-valuemax`, and `aria-valuenow` semantics.
- **Responsive:** The track is fluid; keep any numeric label readable beside or above it.
- **Do:** Clamp and explain values in the expected range.
- **Don't:** Use a determinate percentage when progress cannot actually be measured.
- **Related:** Alert, MetricCard, EnrichmentUsageMetricGroup.
- **Storybook:** `Primitives/Feedback` → Progress.

<!-- component: radio-group -->
### Radio Group

- **Purpose:** Selects exactly one option from a visible set.
- **Usage:** Render `RadioGroup` with uniquely valued `RadioGroupItem` controls and associated labels.
- **API:** Supports controlled/uncontrolled `value`, `defaultValue`, `onValueChange`, orientation, disabled state, and native grouping attributes.
- **Accessibility:** Give the group a label and every item its own visible label.
- **Responsive:** Stack long choices on small screens; use horizontal layout only when labels remain clear.
- **Do:** Use when all mutually exclusive choices should be visible.
- **Don't:** Use for independent boolean settings.
- **Related:** Checkbox, Select, ToggleGroup.
- **Storybook:** `Primitives/Inputs` → Radio Group.

<!-- component: scroll-area -->
### Scroll Area

- **Purpose:** Adds consistent styled scrolling to a bounded region.
- **Usage:** Wrap overflowing content with `ScrollArea`; use the exported scrollbar only for custom compositions.
- **API:** Forwards Radix Scroll Area root props and supports vertical or horizontal `ScrollBar`.
- **Accessibility:** Ensure keyboard users can reach interactive descendants; give a focusable overflow region a name when the region itself must be navigated.
- **Responsive:** Set a deliberate height or max-height and avoid nested same-axis scroll containers.
- **Do:** Use for bounded menus, logs, or panels with predictable dimensions.
- **Don't:** Hide whole-page content inside a small scrolling box without need.
- **Related:** Table, DropdownMenu, Sidebar.
- **Storybook:** `Primitives/Data Display` → Scroll Area.

<!-- component: select -->
### Select

- **Purpose:** Chooses one value from a compact option list.
- **Usage:** Compose root, trigger, value, content, groups, labels, items, and separators.
- **API:** Forwards Radix Select props with `SelectTrigger` sizing and scroll controls.
- **Accessibility:** Associate the trigger with a visible label and keep item text unique and understandable.
- **Responsive:** Use a fluid trigger where needed and rely on viewport-aware content positioning.
- **Do:** Use for a moderate list where seeing every option at once is unnecessary.
- **Don't:** Use for free-form text or an extremely large searchable dataset.
- **Related:** RadioGroup, ProviderSelector, Field.
- **Storybook:** `Primitives/Inputs` → Select.

<!-- component: separator -->
### Separator

- **Purpose:** Visually or semantically divides adjacent groups.
- **Usage:** Set orientation and choose whether the divider is decorative.
- **API:** Forwards Radix Separator props including `orientation` and `decorative`.
- **Accessibility:** Keep purely visual separators decorative; expose semantics only when the division conveys structure.
- **Responsive:** Vertical separators require a parent-defined height; hide separators that no longer match a stacked layout.
- **Do:** Use sparingly between meaningful groups.
- **Don't:** Add separators merely to compensate for weak spacing hierarchy.
- **Related:** Card, DropdownMenu, Sidebar.
- **Storybook:** `Primitives/Data Display` → Separator.

<!-- component: sidebar -->
### Sidebar

- **Purpose:** Provides a responsive application-navigation shell and its composable regions.
- **Usage:** Wrap sidebar layouts in `SidebarProvider` and compose header, content, groups, menu items, footer, rail, inset, and trigger.
- **API:** Exposes provider state through `useSidebar`, controlled `open`/`onOpenChange`, variants, collapsible modes, menu size/active props, and mobile sheet behavior.
- **Accessibility:** Label navigation and icon-only controls, preserve keyboard focus, and mark the active destination semantically.
- **Responsive:** Desktop collapse and mobile off-canvas behavior are built in; verify content and trigger placement at both modes.
- **Do:** Pass route labels and actions from the consuming application.
- **Don't:** Add product routes, permissions, API calls, or domain state to this package.
- **Related:** Breadcrumb, SidebarServiceSearch, Collapsible.
- **Storybook:** `Primitives/Navigation` → Sidebar.

<!-- component: steps -->
### Steps

- **Purpose:** Communicates progress through a short ordered workflow.
- **Usage:** Compose `Steps`, `StepsList`, `Step`, `StepIndicator`, `StepContent`, `StepMeta`, and `StepLabel`; set each item to `complete`, `current`, or `upcoming`.
- **API:** Parts accept native element props; `Step` supports `state` and `asChild` for semantic router links.
- **Accessibility:** Give `Steps` a useful label, mark the current item with `aria-current="step"`, and keep navigation steps as real links.
- **Responsive:** Choose the list columns in the consumer and allow labels to truncate or stack at narrow widths.
- **Do:** Use visible numbers and text so progress does not depend on color or icons.
- **Don't:** Use steps for peer navigation, hide validation state inside them, or place product-specific routing in the primitive.
- **Related:** Progress, Breadcrumb, Tabs, WizardDialogShell.
- **Storybook:** `Primitives/Navigation` → Steps.

<!-- component: switch -->
### Switch

- **Purpose:** Changes an immediately applied on/off setting.
- **Usage:** Pair `Switch` with a visible label and controlled or uncontrolled state.
- **API:** Forwards Radix Switch props such as `checked`, `defaultChecked`, `onCheckedChange`, and `disabled`.
- **Accessibility:** Associate a label that describes the setting, not the action; announce disabled or required context in text.
- **Responsive:** Keep the switch from shrinking and let its label wrap.
- **Do:** Use for a binary setting whose effect is clear.
- **Don't:** Use as a submit button or for a choice that requires confirmation before applying.
- **Related:** Checkbox, Toggle, Field.
- **Storybook:** `Primitives/Inputs` → Switch.

<!-- component: table -->
### Table

- **Purpose:** Presents structured row-and-column data.
- **Usage:** Compose table, header, body, footer, row, head, cell, and caption; add application state outside the primitive.
- **API:** Parts forward their native table element props; `Table` provides an overflow wrapper.
- **Accessibility:** Use real header cells, a caption or nearby heading, meaningful scope, and named keyboard-accessible overflow when needed.
- **Responsive:** Prefer horizontal overflow or a purpose-built compact view; do not silently remove essential columns.
- **Do:** Keep headers concise and align comparable values consistently.
- **Don't:** Use a table only to lay out non-tabular content.
- **Related:** TablePagination, SearchFilterToolbar, BulkActionToolbar.
- **Storybook:** `Primitives/Data Display` → Table.

<!-- component: tabs -->
### Tabs

- **Purpose:** Switches between peer sections without changing the overall task context.
- **Usage:** Compose `Tabs`, `TabsList`, `TabsTrigger`, and matching `TabsContent` values.
- **API:** Forwards Radix Tabs controlled/uncontrolled value, orientation, activation mode, and part props.
- **Accessibility:** Use concise unique trigger labels and preserve built-in keyboard navigation and focus order.
- **Responsive:** Allow the tab list to scroll or adopt another navigation pattern before labels become clipped.
- **Do:** Keep panel content at the same information hierarchy.
- **Don't:** Use tabs as a hidden multi-step wizard or for unrelated destinations.
- **Related:** Breadcrumb, Sidebar, Card.
- **Storybook:** `Primitives/Navigation` → Tabs.

<!-- component: textarea -->
### Textarea

- **Purpose:** Captures multi-line free-form text.
- **Usage:** Pair with a visible label, helpful length guidance, and validation.
- **API:** Forwards native `textarea` props and `ref`.
- **Accessibility:** Connect the label, description, validation message, and any character limit.
- **Responsive:** Defaults to full width; set a sensible minimum height and permit vertical growth.
- **Do:** Use for text that naturally spans multiple lines.
- **Don't:** Use for a short single-line value or silently prevent resizing without a layout reason.
- **Related:** Input, Field, Form.
- **Storybook:** `Primitives/Inputs` → Textarea.

<!-- component: toggle -->
### Toggle

- **Purpose:** Represents a pressable on/off formatting or view state.
- **Usage:** Use a controlled or uncontrolled `Toggle` for an action whose pressed state remains visible.
- **API:** Radix Toggle props plus `variant="default" | "outline"` and `size="default" | "sm" | "lg"`.
- **Accessibility:** Icon-only toggles need an accessible name; pressed state must not be communicated only by color.
- **Responsive:** Use a compact size where necessary while retaining a usable target.
- **Do:** Use for persistent states such as bold formatting or grid view.
- **Don't:** Replace an ordinary one-shot button or a form checkbox without reason.
- **Related:** ToggleGroup, Button, Switch.
- **Storybook:** `Primitives/Actions` → Toggle.

<!-- component: thyris-logo -->
### Thyris Logo

- **Purpose:** Renders the official Thyris mark as a theme-aware inline SVG.
- **Usage:** Place it beside the Thyris product or platform name, or use it as the default mark in `BrandLockup`.
- **API:** Accepts SVG props, `className`, and an optional `title`; the mark inherits `currentColor`.
- **Accessibility:** Omit `title` when adjacent text names Thyris; provide a concise title when the mark is the only identifying content.
- **Responsive:** Set an explicit size and prevent shrinking in compact headers and collapsed sidebars.
- **Do:** Let semantic foreground tokens control light and dark presentation.
- **Don't:** recolor, distort, or use the mark as an unlabeled interactive control.
- **Related:** BrandLockup, AppHeader, AppSidebar.
- **Storybook:** `Patterns/Application Shell` → Brand and Search.

<!-- component: toggle-group -->
### Toggle Group

- **Purpose:** Groups related single- or multi-select pressed controls.
- **Usage:** Compose `ToggleGroup` and uniquely valued `ToggleGroupItem` children.
- **API:** Supports Radix single/multiple selection props plus shared `variant` and `size`.
- **Accessibility:** Give the group and icon-only items accessible names; make selection state clear beyond color.
- **Responsive:** Wrap or horizontally scroll the group before controls become too small.
- **Do:** Use for compact view, alignment, or formatting choices.
- **Don't:** Mix unrelated actions in one group.
- **Related:** Toggle, RadioGroup, Tabs.
- **Storybook:** `Primitives/Actions` → Toggle Group.

<!-- component: tooltip -->
### Tooltip

- **Purpose:** Adds brief supplementary explanation to a focused or hovered trigger.
- **Usage:** Place tooltips under `TooltipProvider` and compose trigger and content.
- **API:** Forwards Radix Tooltip provider, root, trigger, and content props including delay and side offset.
- **Accessibility:** Ensure keyboard users receive the same text and the trigger already has an accessible name.
- **Responsive:** Do not depend on hover; keep content short and collision-aware on touch-size viewports.
- **Do:** Explain an unfamiliar icon or abbreviated value.
- **Don't:** Put critical instructions, errors, or interactive controls only in a tooltip.
- **Related:** Popover, Button, Sidebar.
- **Storybook:** `Primitives/Feedback` → Tooltip.

<!-- component: url-list-input -->
### URL List Input

- **Purpose:** Edits an ordered list of URL strings through a compact input and management popover.
- **Usage:** Pass the current string array, `onChange`, a label, and optional placeholder/description.
- **API:** `value: string[]`, `onChange(value)`, `label`, `placeholder?`, and `description?`.
- **Accessibility:** The add/remove icon buttons have names; callers should provide clear format and validation feedback.
- **Responsive:** The popover is fixed at `w-80`; consuming layouts must verify it fits narrow viewports and provide domain limits externally.
- **Do:** Validate URL format and item limits in the consuming form.
- **Don't:** Add domain-specific limits, uploads, persistence, or API behavior to this primitive.
- **Related:** Input, Popover, ScrollArea.
- **Storybook:** `Primitives/Inputs` → URL List Input.

## Supporting APIs

- `tokens.css` is the canonical light/dark semantic color and radius contract.
- `cn(...inputs)` merges conditional Tailwind classes.
- `useMediaQuery(query)` exposes client-side media-query state. Rendering must
  remain safe before hydration and must not be the only source of critical
  content.

## Integration and change policy

Public exports are defined by `src/index.ts`. Add a Storybook story and a full
documentation entry with every new component. Breaking changes and
deprecations are recorded in
[`design-library/COMPONENT_CHANGELOG.md`](../../design-library/COMPONENT_CHANGELOG.md).
Application-specific behavior belongs in the consumer, even when a primitive
is first created for one product screen.

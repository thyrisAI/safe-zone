# @thyris/ui changelog

All notable public API changes are recorded here. Versions follow Semantic
Versioning while the package remains local and private.

## 0.3.1

- Add reusable monitoring dashboard panels, metrics, progress, and bar charts.

## 0.3.0

- Add reusable selection and section navigation patterns

## Unreleased

- Add the theme-aware `ThyrisLogo` SVG primitive.

## 0.2.0

- Add the composable `Steps` navigation primitive with complete, current, and upcoming states.

## 0.1.1

- Add the consumer usage guide and portable quality checks

## 0.1.0

- Initial local-release baseline for the canonical UI primitives, tokens, and
  utilities.
